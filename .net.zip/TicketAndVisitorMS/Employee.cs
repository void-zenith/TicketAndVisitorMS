﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TicketAndVisitorMS
{
    public class Employee
    {
        public string employeeID { get; set; }

        public string employeeUserName { get; set; }

        public string employeePassword { get; set; }

        public string employeeName { get; set; }

        public string employeeRole { get; set; }

        public string employeeEmail { get; set; }

        public string employeeMobileNumber { get; set; }

        public string employeeAddress { get; set; }
    }
}